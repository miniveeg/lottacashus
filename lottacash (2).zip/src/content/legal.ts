export const PRIVACY_POLICY = `
Last updated: May 2026

1. Introduction
LottaCash ("we," "us," "our") respects your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our platform, website, and related services (collectively, the "Service"). By using the Service, you agree to the practices described in this policy.

2. Information we collect
We collect information you provide directly when you create an account, make a deposit or withdrawal, or contact support. This includes your email address, username, and any communications you send us. We also collect information automatically through your use of the Service, including your IP address, browser type, device information, pages visited, and transaction data. We use cookies and similar tracking technologies to collect usage data and improve the Service.

3. How we use your information
We use the information we collect to operate, maintain, and improve the Service; to process transactions and maintain your account; to communicate with you about updates, security, and support; to detect and prevent fraud, abuse, and illegal activity; to comply with legal obligations; and to analyze usage trends.

4. Sharing of information
We do not sell your personal information. We may share your information with service providers who help us operate the platform (such as cloud hosting, payment processing, and email delivery), when required by law or legal process, to protect our rights or the safety of others, or in connection with a merger or acquisition of our business.

5. Data retention
We retain your personal information for as long as your account is active or as needed to provide the Service. We may retain certain information longer to comply with legal obligations, resolve disputes, and enforce our agreements.

6. Your rights and choices
Depending on your jurisdiction, you may have the right to access, correct, delete, or port your personal data. You may update your account information through your settings at any time. You may delete your account by contacting support. You can opt out of marketing emails by following the unsubscribe link in any such email.

7. Security
We implement reasonable technical and organizational measures to protect your information from unauthorized access, alteration, disclosure, or destruction. However, no method of transmission or storage is completely secure, and we cannot guarantee absolute security.

8. Third-party links
The Service may contain links to third-party websites or services. We are not responsible for the privacy practices of those third parties.

9. Children
The Service is not intended for individuals under the age of 18. We do not knowingly collect personal information from minors. If we learn that we have collected information from a minor, we will delete it promptly.

10. Changes to this policy
We may update this Privacy Policy from time to time. Material changes will be posted on this page, and we will notify you through the Service or by email as required by applicable law.

11. Contact
If you have questions about this Privacy Policy, please contact us at support@lottacash.us.
`.trim();

export const SWEEPSTAKES_RULES = `
Last updated: May 2026

1. Overview
These Sweepstakes Rules govern all sweepstakes promotions offered by LottaCash ("the Promoter") on the LottaCash platform. Participation constitutes acceptance of these rules. No purchase or payment of any kind is necessary to enter or win. A purchase will not increase your chances of winning.

2. Eligibility
Participants must be at least 18 years old (or the age of majority in their jurisdiction, whichever is higher) and legal residents of a jurisdiction where participation is permitted. Employees of the Promoter, its affiliates, and their immediate family members are not eligible. Sweepstakes are void in jurisdictions where prohibited by law, including but not limited to Washington, Idaho, and any other restricted state or territory.

3. How to enter free of charge
You may obtain Sweeps Coins (SC) free of charge by mailing a handwritten request to the address below. Include your username, email address associated with your LottaCash account, and return address. Limit one request per household per calendar month. SC will be credited to your account within 14 business days of receipt. There is no purchase necessary to enter, and no purchase increases your odds of winning.

Mailing address:
LottaCash Sweepstakes
[Address Line 1]
[City, State ZIP]

We are currently setting up our mailing address. Check back soon or contact support@lottacash.us with questions.

4. How to enter with purchase
When you purchase Gold Coins (GC), you receive a bonus allocation of Sweeps Coins at the rate specified at the time of purchase (currently 1% of the purchase amount in SC). This allocation is a promotional bonus and does not affect your odds in any sweepstakes game.

5. Prizes and odds
Sweeps Coins (SC) may be redeemed for real-money prizes at the rate of 1 SC = $0.10 USD, with a minimum redemption of 100 SC ($10 equivalent). Odds of winning depend on the game selected and are displayed within each game on the platform. All prizes are awarded as cash equivalents transferred to your designated PayPal account.

6. Prize claim process
To redeem SC for prizes, submit a redemption request through the Redeem page on the platform. Provide a valid PayPal email address. Redemptions are processed after verification and may take up to 3–5 business days. The Promoter reserves the right to verify eligibility and identity before processing any redemption.

7. General conditions
The Promoter reserves the right to modify, suspend, or terminate sweepstakes at any time without prior notice. All decisions of the Promoter are final and binding. Participants agree to release and hold harmless the Promoter from any liability arising from participation or prize award.

8. Taxes
Participants are solely responsible for any taxes, fees, or duties associated with accepting a prize. The Promoter may issue tax forms as required by applicable law.

9. Governing law
These Sweepstakes Rules are governed by the laws applicable to the jurisdiction of the Promoter. Any disputes shall be resolved in the courts or arbitration as designated by the Promoter.

10. Contact
For questions about these rules or to request free entry via mail, contact support@lottacash.us.
`.trim();
