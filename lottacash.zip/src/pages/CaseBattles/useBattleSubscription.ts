/**
 * Case Battles v2 — realtime hooks.
 * Replaces the old 1.5s polling with Supabase realtime subscriptions.
 * Battle updates push instantly — zero polling lag.
 */

import { useEffect, useRef, useState, useCallback } from "react";
import { supabase, isSupabaseConfigured } from "../../lib/supabase";
import { viewCaseBattle, listOpenBattles } from "./caseBattlesApi";
import type { CaseBattleView } from "./types";

/**
 * Subscribes to a single battle's realtime updates.
 * Returns the latest battle state. Re-fetches on any change to the battle,
 * its players, or its drops.
 */
export function useBattleSubscription(battleId: string | undefined): {
  battle: CaseBattleView | null;
  loading: boolean;
  error: string | null;
  refetch: () => void;
} {
  const [battle, setBattle] = useState<CaseBattleView | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const cancelledRef = useRef(false);

  const fetchBattle = useCallback(async () => {
    if (!battleId || cancelledRef.current) return;
    const { data, error: err } = await viewCaseBattle(battleId);
    if (cancelledRef.current) return;
    if (err) {
      setError(err);
      setBattle(null);
    } else {
      setError(null);
      setBattle(data);
    }
    setLoading(false);
  }, [battleId]);

  useEffect(() => {
    cancelledRef.current = false;
    setLoading(true);
    setBattle(null);
    setError(null);
    fetchBattle();

    if (!isSupabaseConfigured || !battleId) return;

    // Subscribe to all three tables for this battle. Any change triggers a
    // single re-fetch (the fetch is debounced by React's state batching).
    const channel = supabase
      .channel(`battle-${battleId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "case_battles", filter: `id=eq.${battleId}` },
        () => fetchBattle(),
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "case_battle_players", filter: `battle_id=eq.${battleId}` },
        () => fetchBattle(),
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "case_battle_drops", filter: `battle_id=eq.${battleId}` },
        () => fetchBattle(),
      )
      .subscribe();

    return () => {
      cancelledRef.current = true;
      supabase.removeChannel(channel);
    };
  }, [battleId, fetchBattle]);

  // Local-play polling: when the battle exists in the local in-memory store
  // (no realtime subscription will fire), poll every 400ms so the UI picks up
  // state changes (add bot, start, resolve, claim).
  useEffect(() => {
    if (!battleId) return;
    let active = true;
    const iv = setInterval(async () => {
      if (!active) return;
      const { localViewCaseBattle } = await import("../../lib/local-case-battles");
      const local = localViewCaseBattle(battleId);
      if (local) await fetchBattle();
    }, 400);
    return () => { active = false; clearInterval(iv); };
  }, [battleId, fetchBattle]);

  return { battle, loading, error, refetch: fetchBattle };
}

/**
 * Subscribes to the lobby list (all open battles).
 * Returns the list + a manual refresh function.
 */
export function useLobbySubscription() {
  const [battles, setBattles] = useState<CaseBattleView[]>([]);
  const [loading, setLoading] = useState(true);
  const cancelledRef = useRef(false);

  const fetchLobby = useCallback(async () => {
    const { data, error } = await listOpenBattles();
    if (cancelledRef.current) return;
    if (error || !data) {
      setBattles([]);
    } else {
      // Attach player count as a synthetic field for display.
      const views = data as any[];
      views.forEach((v) => { v._playerCount = v.players?.length ?? 0; });
      setBattles(views);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    cancelledRef.current = false;
    fetchLobby();

    if (!isSupabaseConfigured) {
      // Local-play polling: refresh lobby every 1s to pick up new local battles.
      const iv = setInterval(() => fetchLobby(), 1000);
      return () => { cancelledRef.current = true; clearInterval(iv); };
    }

    const channel = supabase
      .channel("lobby")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "case_battles" },
        () => fetchLobby(),
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "case_battle_players" },
        () => fetchLobby(),
      )
      .subscribe();

    return () => {
      cancelledRef.current = true;
      supabase.removeChannel(channel);
    };
  }, [fetchLobby]);

  return { battles, loading, refetch: fetchLobby };
}
