import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { corsHeaders, jsonResponse } from "../_shared/cors.ts";

function bytesToFloat(bytes: Uint8Array, offset = 0): number {
  let value = 0;
  for (let i = 0; i < 4; i++) {
    value += bytes[offset + i]! / Math.pow(256, i + 1);
  }
  return value;
}

async function hmacSha256(key: string, message: string): Promise<Uint8Array> {
  const enc = new TextEncoder();
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    enc.encode(key),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", cryptoKey, enc.encode(message));
  return new Uint8Array(sig);
}

function truncateCrashMultiplier(value: number): number {
  return Math.trunc(value * 100) / 100;
}

async function crashPointFromSeeds(serverSeed: string, clientSeed: string, nonce: number): Promise<number> {
  const msg = `${clientSeed}:${nonce}:0`;
  const hash = await hmacSha256(serverSeed, msg);
  const float = bytesToFloat(hash, 0);
  const scaled = float * 16777216;
  // 96.5% RTP: P(point >= x) = 0.965/x  =>  EV of "cash at t" = 0.965.
  const raw = (16777216 / (scaled + 1)) * 0.965;
  return truncateCrashMultiplier(Math.max(1, raw));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders(req) });
  }

  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405, req);
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return jsonResponse({ error: "Log in required." }, 401, req);

    const body = await req.json();
    const wager = Number(body?.wager);
    const coinType = String(body?.coinType ?? "balance");

    if (!Number.isFinite(wager) || wager < 1) {
      return jsonResponse({ error: "Minimum bet is 1 SC or GC." }, 400, req);
    }

    // Max-payout cap: the crash formula can produce up to ~1,000,000× but we
    // cap the potential payout at 100,000. With a worst-case multiplier of
    // 1,000× (the 99.99th percentile), the max allowed wager is 100. This
    // keeps the game playable (min wager 1, max ~100) while capping exposure.
    const CRASH_MAX_PAYOUT = 100_000;
    const crashWorstCaseMultiplier = 1_000;
    const crashPotentialPayout = Math.round(wager * crashWorstCaseMultiplier * 100) / 100;
    if (crashPotentialPayout > CRASH_MAX_PAYOUT) {
      return jsonResponse(
        { error: `Potential payout exceeds the maximum allowed (${CRASH_MAX_PAYOUT.toLocaleString()}). Lower your wager.` },
        400,
        req,
      );
    }

    const supabaseUser = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const {
      data: { user },
      error: userError,
    } = await supabaseUser.auth.getUser();

    if (userError || !user) return jsonResponse({ error: "Invalid session." }, 401, req);

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: excluded } = await supabaseAdmin.rpc("check_user_self_exclusion", {
      p_user_id: user.id,
    });
    if (excluded) {
      return jsonResponse({ error: "Your account is self-excluded." }, 403, req);
    }

    const coinColumn = coinType === "sweeps_coins" ? "sweeps_coins" : "balance";

    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select(coinColumn)
      .eq("id", user.id)
      .maybeSingle();

    const balance = Number(profile?.[coinColumn as keyof typeof profile] ?? 0);
    if (balance < wager) {
      return jsonResponse({ error: "Insufficient balance" }, 400, req);
    }

    const { data: seedData, error: seedError } = await supabaseAdmin.rpc(
      "consume_keno_nonce",
      { p_user_id: user.id, p_advance: 1 }
    );

    if (seedError) {
      console.error("consume_keno_nonce:", seedError);
      return jsonResponse({ error: seedError.message ?? "Could not load game seeds." }, 500, req);
    }

    const raw = (Array.isArray(seedData) ? seedData[0] : seedData) as
      | Record<string, unknown>
      | undefined;
    const serverSeed = raw?.server_seed ?? raw?.serverSeed;
    const clientSeed = raw?.client_seed ?? raw?.clientSeed ?? "default";
    const nonce = Number(raw?.nonce ?? raw?.next_nonce ?? 0);

    if (typeof serverSeed !== "string" || !serverSeed) {
      return jsonResponse({ error: "Could not load game seeds." }, 500, req);
    }

    const crashPoint = await crashPointFromSeeds(serverSeed, String(clientSeed), nonce);

    const { data: placed, error: placeError } = await supabaseAdmin.rpc(
      "place_crash_bet",
      {
        p_user_id: user.id,
        p_wager: wager,
        p_crash_point: crashPoint,
        p_nonce: nonce,
        p_coin_type: coinType,
      }
    );

    if (placeError) {
      console.error("place_crash_bet:", placeError);
      return jsonResponse({ error: placeError.message }, 400, req);
    }

    const row = (Array.isArray(placed) ? placed[0] : placed) as
      | Record<string, unknown>
      | undefined;

    return jsonResponse({
      betId: row?.bet_id,
      // SECURITY: do NOT return crashPoint here. The client learns the crash
      // point only when the round resolves (settle-loss / a dedicated reveal
      // endpoint). Returning it in the bet-creation response lets a client
      // know the bust point before deciding when to cash out — defeating the
      // game. The Crash UI derives its animation curve from the server's
      // cash_out_crash / crash_settle_loss responses instead.
      won: false,
      payout: 0,
      cashedAt: null,
      nonce,
      balance: Number(row?.out_balance ?? balance - wager),
      coinType,
    });
  } catch (err) {
    console.error("place-crash-bet:", err);
    return jsonResponse({ error: "Server error." }, 500, req);
  }
});
